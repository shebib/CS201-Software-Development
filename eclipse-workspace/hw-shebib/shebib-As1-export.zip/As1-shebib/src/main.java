
/**
 * This program reads in students from a json file, allows
 * changes and sorting, then outputs to the same file
 * This class begins the program
 * @author Daniel Shebib
 *
 */
public class main {

	public static void main(String[] args) {
		MainInterface txtInterface = new MainInterface();
		
	}

}
	