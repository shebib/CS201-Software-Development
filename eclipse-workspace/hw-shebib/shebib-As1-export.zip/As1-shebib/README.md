# Assignment 1
### Daniel Shebib, 9101159372

## Instructions
To run, simply compile and run main.

## Description
This file reads in data entries from a json file as a list of students. The user can then use the terminal to sort, add, remove, and otherwise manipulate the data, before saving it back to the json file.

## Json format
Students: List of Student
Student: double average, double numGrades, Name
Name: String fname, String lname
